System Migration Note (2018):

- Admin hated changing passwords
- Password length >= 8
- Used common words + year

"Nothing important here, right?"
