import os
from flask import Flask, request, render_template_string
import sqlite3
import bcrypt

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "users.db")

HTML = """
<h2>🔐 Secure Login</h2>
<form method="post">
  Username: <input name="username"><br><br>
  Password: <input name="password" type="password"><br><br>
  <button>Login</button>
</form>
<p>{{ msg }}</p>
"""

def get_user(username):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT password_hash FROM users WHERE username=?", (username,))
    row = cur.fetchone()
    conn.close()
    return row[0] if row else None

@app.route("/", methods=["GET", "POST"])
def login():
    msg = ""
    if request.method == "POST":
        user = request.form["username"]
        pw = request.form["password"].encode()

        hash_pw = get_user(user)
        if hash_pw and bcrypt.checkpw(pw, hash_pw.encode()):
            msg = "✅ LOGIN SUCCESS<br>FLAG{PASSWORD_REUSE_IS_DANGEROUS}"
        else:
            msg = "❌ Invalid credentials"

    return render_template_string(HTML, msg=msg)

if __name__ == "__main__":
    app.run(debug=True)
