import sqlite3

conn = sqlite3.connect("users.db")
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    username TEXT,
    password_hash TEXT
)
""")

cur.execute("""
INSERT INTO users VALUES (
    'admin',
    '$2b$12$gS9E2630rAy3XWz4HIwiWuVI2W/dhI5LHq4PYlLCbXKj2AlpTJBvq'
)
""")

conn.commit()
conn.close()

print("✅ users.db created")
